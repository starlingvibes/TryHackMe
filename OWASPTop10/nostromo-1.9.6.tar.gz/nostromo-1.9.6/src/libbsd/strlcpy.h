size_t	strlcpy(char *, const char *, size_t);
