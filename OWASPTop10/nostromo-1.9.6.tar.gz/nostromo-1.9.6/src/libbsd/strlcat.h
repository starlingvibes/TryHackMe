size_t	strlcat(char *, const char *, size_t);
