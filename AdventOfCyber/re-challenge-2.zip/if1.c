#include <stdio.h>

int main(void){
  int a = 3;
  int b = 4;
  if(a < b){
    a += 5;
  }
  else{
    b += 3;
  }
  return 0;
}
